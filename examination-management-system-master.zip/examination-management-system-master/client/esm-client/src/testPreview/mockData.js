export const questions = [
  {
    description: "who is question 1?",
    options: [
      {
        option: "I don't know",
      },
      {
        option: "I know the answer",
      },
      {
        option: "Where is the answer",
      },
      {
        option: "Everone know the answer",
      },
    ],
  },
  {
    description: "who is question 2?",
    options: [
      {
        option: "Well Hello",
      },
      {
        option: "wow",
      },
      {
        option: "Hey",
      },
      {
        option: "So befutful",
      },
    ],
  },
  {
    description: "who is question 3?",
    options: [
      {
        option: "Yay",
      },
      {
        option: "Boo",
      },
      {
        option: "Kingg",
      },
      {
        option: "Queen",
      },
    ],
  },
  {
    description: "who is question 4?",
    options: [
      {
        option: "I don't know",
      },
      {
        option: "I know the answer",
      },
      {
        option: "Where is the answer",
      },
      {
        option: "Everone know the answer",
      },
    ],
  },
  {
    description: "who is question 5?",
    options: [
      {
        option: "I don't know",
      },
      {
        option: "I know the answer",
      },
      {
        option: "Where is the answer",
      },
      {
        option: "Everone know the answer",
      },
    ],
  },
];
